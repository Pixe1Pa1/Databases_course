--
-- PostgreSQL database dump
--

\restrict r4wfupC5WcPg6YUuOWtuzeKhe9dZlyLdi7t3yTFMiPPkNK8QqwbGpeH3aBNQ0zd

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-18 07:44:10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4874 (class 0 OID 16407)
-- Dependencies: 221
-- Data for Name: access; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.access VALUES (301, 1, 101, 'редагування', '2023-10-01 13:00:00+03', '2033-10-01 13:00:00+03');
INSERT INTO public.access VALUES (302, 2, 101, 'читання', '2023-10-20 14:00:00+03', '2024-10-20 14:00:00+03');


--
-- TOC entry 4872 (class 0 OID 16397)
-- Dependencies: 219
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.document VALUES (101, 1, 10, 'Специфікація API для модуля авторизації', 'Опис методів та кінцевих точок API v2.1', '2023-10-01 13:00:00+03', '2023-10-15 17:30:00+03', 2);
INSERT INTO public.document VALUES (102, 2, 11, 'Інструкція з налаштування 2FA', 'Гайд щодо підвищення безпеки акаунта', '2023-11-05 11:00:00+02', '2023-11-05 11:00:00+02', 1);


--
-- TOC entry 4870 (class 0 OID 16387)
-- Dependencies: 217
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.employee VALUES (1, 'Іван', 'Петренко', 'ivan.petrenko@example.com', 'Відділ розробки');
INSERT INTO public.employee VALUES (2, 'Олена', 'Коваленко', 'olena.kovalenko@example.com', 'Відділ аналітики');


--
-- TOC entry 4873 (class 0 OID 16402)
-- Dependencies: 220
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.file VALUES (201, 101, 'auth_api_v2.1', 'PDF', 1024, '2023-10-01 13:05:00+03');
INSERT INTO public.file VALUES (202, 102, '2fa_guide', 'DOCX', 512, '2023-11-05 11:10:00+02');


--
-- TOC entry 4871 (class 0 OID 16392)
-- Dependencies: 218
-- Data for Name: сategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."сategory" VALUES (10, 'Технічні специфікації', 'Детальні описи продуктів та архітектурних рішень', 'Внутрішня');
INSERT INTO public."сategory" VALUES (11, 'Посібники користувача', 'Інструкції та гайди для кінцевих користувачів', 'Публічна');


-- Completed on 2025-09-18 07:44:11

--
-- PostgreSQL database dump complete
--

\unrestrict r4wfupC5WcPg6YUuOWtuzeKhe9dZlyLdi7t3yTFMiPPkNK8QqwbGpeH3aBNQ0zd

