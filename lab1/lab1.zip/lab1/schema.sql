--
-- PostgreSQL database dump
--

\restrict eHQ50fOr587cnIDsyHMUFHGuJdfZcGYB8g67i1FhEfc38xXMgI2bN2dMHRweU4r

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

-- Started on 2025-09-18 07:32:31

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 221 (class 1259 OID 16407)
-- Name: access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.access (
    access_id integer NOT NULL,
    employee_id integer NOT NULL,
    document_id integer NOT NULL,
    access_level character varying(50) NOT NULL,
    date_granted timestamp with time zone NOT NULL,
    expiry_date timestamp with time zone NOT NULL
);


ALTER TABLE public.access OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16397)
-- Name: document; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document (
    document_id integer NOT NULL,
    employee_id integer NOT NULL,
    category_id integer NOT NULL,
    title character varying(50) NOT NULL,
    description character varying(50) NOT NULL,
    date_created timestamp with time zone NOT NULL,
    date_updated timestamp with time zone NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.document OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16387)
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    department character varying(50) NOT NULL
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16402)
-- Name: file; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.file (
    file_id integer NOT NULL,
    document_id integer NOT NULL,
    file_name character varying(50) NOT NULL,
    format character varying(50) NOT NULL,
    size integer NOT NULL,
    upload_date timestamp with time zone NOT NULL
);


ALTER TABLE public.file OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16392)
-- Name: сategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."сategory" (
    category_id integer NOT NULL,
    category_name character varying(50) NOT NULL,
    description character varying(50) NOT NULL,
    type character varying(50) NOT NULL
);


ALTER TABLE public."сategory" OWNER TO postgres;

--
-- TOC entry 4719 (class 2606 OID 16411)
-- Name: access access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_pkey PRIMARY KEY (access_id);


--
-- TOC entry 4715 (class 2606 OID 16401)
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (document_id);


--
-- TOC entry 4711 (class 2606 OID 16391)
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- TOC entry 4717 (class 2606 OID 16406)
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (file_id);


--
-- TOC entry 4713 (class 2606 OID 16396)
-- Name: сategory сategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."сategory"
    ADD CONSTRAINT "сategory_pkey" PRIMARY KEY (category_id);


--
-- TOC entry 4723 (class 2606 OID 16427)
-- Name: access access_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(document_id) NOT VALID;


--
-- TOC entry 4724 (class 2606 OID 16432)
-- Name: access access_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.access
    ADD CONSTRAINT access_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employee(employee_id) NOT VALID;


--
-- TOC entry 4720 (class 2606 OID 16417)
-- Name: document document_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_category_id_fkey FOREIGN KEY (category_id) REFERENCES public."сategory"(category_id) NOT VALID;


--
-- TOC entry 4721 (class 2606 OID 16412)
-- Name: document document_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employee(employee_id) NOT VALID;


--
-- TOC entry 4722 (class 2606 OID 16422)
-- Name: file file_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.document(document_id) NOT VALID;


-- Completed on 2025-09-18 07:32:31

--
-- PostgreSQL database dump complete
--

\unrestrict eHQ50fOr587cnIDsyHMUFHGuJdfZcGYB8g67i1FhEfc38xXMgI2bN2dMHRweU4r

